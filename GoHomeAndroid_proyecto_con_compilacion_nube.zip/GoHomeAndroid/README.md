# Go.home Android — proyecto inicial

Este proyecto crea una app Android que abre la tienda `https://axissoft.market/gohome` dentro de una vista WebView.

## Qué incluye
- Navegación de vuelta con el botón Atrás de Android.
- JavaScript y almacenamiento web habilitados para que puedan funcionar el catálogo, carrito y sesión si el sitio los soporta.
- Barra de progreso de carga.
- Enlaces a WhatsApp, teléfono, correo, pagos y otras webs enviados a la aplicación externa o navegador correspondiente.
- Solo permite dentro de la app las páginas HTTPS de `axissoft.market`.

## Importante
Esto es un **proyecto fuente inicial**, no un APK ya compilado. La tienda se muestra dentro de la app; el carrito, inventario, checkout, métodos de pago, cuentas y pedidos siguen dependiendo de las funciones reales del sitio web. No he podido verificar desde la lectura automática el flujo interno del carrito ni de pagos, por lo que deben probarse en un teléfono antes de distribuirla.

## Cómo generar el APK
1. Instala Android Studio en una computadora.
2. Descomprime el ZIP y abre la carpeta `GoHomeAndroid` en Android Studio.
3. Deja que Gradle sincronice y descargue las dependencias.
4. Conecta un Android o usa un emulador y prueba catálogo, carrito, finalizar compra, WhatsApp y enlaces de pago.
5. Para crear un APK de prueba: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio mostrará la ubicación del APK generado.

## Antes de entregarla a clientes
- Confirma que tienes permiso para empaquetar el sitio en una app.
- Prueba inicio de sesión, cookies, subida de archivos si existe, pagos y enlaces externos.
- Añade un icono definitivo y revisa nombre, política de privacidad y tratamiento de datos.
- No incluyas contraseñas, claves de pago ni secretos en el código.
- Si el checkout abre una ventana emergente o un proveedor externo, puede requerir ajustes adicionales.

## Datos del proyecto
- Nombre visible: Go.home
- Identificador Android: `com.elehogar.gohome`
- URL inicial: `https://axissoft.market/gohome`
- SDK objetivo: 35
